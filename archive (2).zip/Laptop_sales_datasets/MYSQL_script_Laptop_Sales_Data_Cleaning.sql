use practice;

SELECT * FROM laptop_data;

ALTER TABLE laptop_data
DROP MyUnknownColumn;

SELECT* FROM laptop_data;

describe laptop_data;

--------------------------------------------------------------------------------------------------------------------------
SELECT ScreenResolution,
CASE WHEN ScreenResolution LIKE "%IPS%" THEN 1 ELSE 0 END AS IPS_Panel
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
SELECT ScreenResolution,
CASE WHEN ScreenResolution LIKE "%Touch%" THEN 1 ELSE 0 END AS Touch_Screen
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
SELECT DISTINCT Cpu,
SUBSTRING(Cpu, 1, INSTR(TRIM(Cpu), " ")) AS Processor
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
SELECT DISTINCT Ram,
TRIM(REPLACE(Ram, "GB", "")) AS RAM
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
SELECT DISTINCt Memory,
CASE WHEN Memory like "%SSD%" THEN 1  ELSE 0 end AS SSD_Storage,
CASE WHEN Memory like "%HDD%" THEN 1  ELSE 0 END AS HDD_Storage,
((CASE WHEN Memory like "%Hybrid%" THEN 1  ELSE 0 END) or (CASE WHEN Memory like "%Flash%" THEN 1  ELSE 0 END)) AS Other_Storage 
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
-- Extracting only GPU company name
select distinct Gpu,
substring_index(Gpu, " ", 1) as GPU
from laptop_data;

--------------------------------------------------------------------------------------------------------------------------
-- Extracting Operating System name
SELECT DISTINCT OpSys,
CASE WHEN OpSys LIKE "%No OS%" THEN "No OS" ELSE SUBSTRING_INDEX(OpSys, " ",1) END AS Op_Sys
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
-- Removing kg word from Weight column
SELECT DISTINCT Weight,
REPLACE(Weight, "kg", "") AS Weight_kg
FROM laptop_data;

--------------------------------------------------------------------------------------------------------------------------
-- Extracting storage from Memory column
with CTE1 as (select Memory,
	case when Memory not like "%+%" then Memory else 0 end as single_p,
	case when Memory like "%+%" then Memory else 0 end as dual_p
	from laptop_data),
    
CTE2 as ( select*,
	case when single_p like "%TB%" then left(single_p,1)*1024 else 0 end as TB,
	case when single_p like "%GB SSD%" then replace(single_p,"GB SSD","") else 0 end as SSD,
	case when single_p like "%GB HDD%" then replace(single_p,"GB HDD","") else 0 end as HDD,
	case when single_p like "%GB Flash%" or single_p like "%GB Hybrid%" then  substring(single_p,1,instr(single_p,"G")-1) else 0 end as Other_Storage,
	substring_index(dual_p, "+",1) as p1,
	substring_index(dual_p, "+",-1) as p2
	from CTE1),
    
final_CTE as (
	select SSD,HDD+TB as HDD,Other_Storage,p1,p2,
	case when p1 like "%GB SSD%" then substring(p1,1,instr(p1,"G")-1) else 0 end as p1_SSD,
	case when p1 like "%TB%" then substring(p1,1,instr(p1,"T")-1)*1024  else 0 end  as p1_SSD2, 
	case when p2 like"%GB SSD%" then substring(p2,1,instr(p2,"G")-1) else 0 end as p2_SSD,
       case when p1 like "%Flash%" then substring(p2,1, instr(p2,"G")-1) else 0 end as p1_other,
	case when p2 like"%GB HDD%" then substring(p2,1,instr(p2,"G")-1) else 0 end as p2_HDD, 
	case when p2 like "%TB%" then substring(p2,1,instr(p2,"T")-1)*1024 else 0 end  as P2_HDD2,
    case when p2 like "%TB hybrid%" then substring(p2,1, instr(p2,"T")-1)*1024 else 0 end as p2_other
	from CTE2)
select (SSD+p1_SSD+p2_SSD+p1_SSD2) as SSD_storage, (HDD+p2_HDD+p2_HDD2) as HDD_storage, (Other_Storage+p1_other+p2_other) as Other_storage
from final_CTE;


-------------------------------------------------------------------------------------------------------------------------------------------

 -- Data cleaning Query:
WITH cleaned_dataset AS(
	SELECT Company, TypeName, Inches as Disp_size, 
	TRIM(SUBSTRING(ScreenResolution, INSTR(ScreenResolution, "X")+1,4)) AS y_resolution,
	RIGHT(TRIM(LEFT(ScreenResolution, INSTR(ScreenResolution, "X")-1)),4) AS x_resolution,
	CASE WHEN ScreenResolution LIKE "%IPS%" THEN 1 ELSE 0 END AS IPS_Panel,
	CASE WHEN ScreenResolution LIKE "%Touch%" THEN 1 ELSE 0 END AS Touch_Screen,
	SUBSTRING(Cpu, 1, INSTR(TRIM(Cpu), " ")) AS Processor,
	TRIM(REPLACE(Ram, "GB", "")) AS RAM_GB,
	CASE WHEN Memory like "%SSD%" THEN 1  ELSE 0 end AS SSD_Storage,
	CASE WHEN Memory like "%HDD%" THEN 1  ELSE 0 END AS HDD_Storage,
	((CASE WHEN Memory like "%Hybrid%" THEN 1  ELSE 0 END) or (CASE WHEN Memory like "%Flash%" THEN 1  ELSE 0 END)) AS HybridFlash_storage,
	substring_index(Gpu, " ", 1) as GPU,
	CASE WHEN OpSys LIKE "%No OS%" THEN "No OS" ELSE SUBSTRING_INDEX(OpSys, " ",1) END AS Op_Sys,
	REPLACE(Weight, "kg", "") AS Weight_kg,
	round(Price) as Price_INR
	FROM laptop_data)
SELECT Company, TypeName, Disp_size, IPS_Panel, Touch_Screen, Processor, RAM_GB, SSD_Storage, HDD_Storage,
HybridFlash_storage, GPU, Op_Sys, Weight_kg, Price_INR,
round(SQRT(power(y_resolution,2)+power(x_resolution,2)/POWER(Disp_size,2))) as PPI
FROM cleaned_dataset;

--------------------------------------------------------------------------------------------------------------------------
-- Finall Cleaned Dataset
-- CREATE TABLE laptop_sales_cleaned_dataset AS
WITH cleaned_dataset AS(
	SELECT *,Inches as Disp_size,
	TRIM(SUBSTRING(ScreenResolution, INSTR(ScreenResolution, "X")+1,4)) AS y_resolution,
	RIGHT(TRIM(LEFT(ScreenResolution, INSTR(ScreenResolution, "X")-1)),4) AS x_resolution,
	CASE WHEN ScreenResolution LIKE "%IPS%" THEN 1 ELSE 0 END AS IPS_Panel,
	CASE WHEN ScreenResolution LIKE "%Touch%" THEN 1 ELSE 0 END AS Touch_Screen,
	SUBSTRING(Cpu, 1, INSTR(TRIM(Cpu), " ")) AS Processor,
	TRIM(REPLACE(Ram, "GB", "")) AS RAM_GB,
	CASE WHEN Memory like "%SSD%" THEN 1  ELSE 0 end AS SSD_Disk,
	CASE WHEN Memory like "%HDD%" THEN 1  ELSE 0 END AS HDD_Disk,
	((CASE WHEN Memory like "%Hybrid%" THEN 1  ELSE 0 END) or (CASE WHEN Memory like "%Flash%" THEN 1  ELSE 0 END)) AS HybridFlash_Disk,
	substring_index(Gpu, " ", 1) as GPU_company,
	CASE WHEN OpSys LIKE "%No OS%" THEN "No OS" ELSE SUBSTRING_INDEX(OpSys, " ",1) END AS Op_Sys,
	REPLACE(Weight, "kg", "") AS Weight_kg,
	round(Price) as Price_INR
	FROM laptop_data),

CTE1 as (select*,
	case when Memory not like "%+%" then Memory else 0 end as single_p,
	case when Memory like "%+%" then Memory else 0 end as dual_p
	from cleaned_dataset),
    
CTE2 as ( select*,
	case when single_p like "%TB%" then left(single_p,1)*1024 else 0 end as TB,
	case when single_p like "%GB SSD%" then replace(single_p,"GB SSD","") else 0 end as SSD,
	case when single_p like "%GB HDD%" then replace(single_p,"GB HDD","") else 0 end as HDD,
	case when single_p like "%GB Flash%" or single_p like "%GB Hybrid%" then  substring(single_p,1,instr(single_p,"G")-1) else 0 end as Other_Storage,
	substring_index(dual_p, "+",1) as p1,
	substring_index(dual_p, "+",-1) as p2
	from CTE1),
    
final_CTE as (
	select*,
	case when p1 like "%GB SSD%" then substring(p1,1,instr(p1,"G")-1) else 0 end as p1_SSD,
	case when p1 like "%TB%" then substring(p1,1,instr(p1,"T")-1)*1024  else 0 end  as p1_SSD2, 
	case when p2 like"%GB SSD%" then substring(p2,1,instr(p2,"G")-1) else 0 end as p2_SSD,
	case when p1 like "%Flash%" then substring(p2,1, instr(p2,"G")-1) else 0 end as p1_other,
	case when p2 like"%GB HDD%" then substring(p2,1,instr(p2,"G")-1) else 0 end as p2_HDD, 
	case when p2 like "%TB%" then substring(p2,1,instr(p2,"T")-1)*1024 else 0 end  as P2_HDD2,
    case when p2 like "%TB hybrid%" then substring(p2,1, instr(p2,"T")-1)*1024 else 0 end as p2_other
	from CTE2)
select Company, TypeName, Disp_size, IPS_Panel, Touch_Screen, Processor, RAM_GB, SSD_Disk, HDD_Disk,  
HybridFlash_Disk, GPU_company, Op_Sys, Weight_kg, Price_INR, 
round(SQRT(power(y_resolution,2)+power(x_resolution,2)/POWER(Disp_size,2))) as PPI,
(SSD+p1_SSD+p2_SSD+p1_SSD2) as SSD_storage, 
(HDD+p2_HDD+p2_HDD2) as HDD_storage, 
(Other_Storage+p1_other+p2_other) as Other_storage
from final_CTE;







